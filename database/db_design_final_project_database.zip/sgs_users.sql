-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sgs
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'First10','Last151','un21','pw51','un21@domain137.edu',NULL),(2,'First120','Last158','un148','pw16','un148@domain49.edu',NULL),(3,'First84','Last87','un174','pw36','un174@domain115.edu',NULL),(4,'First73','Last168','un91','pw190','un91@domain131.edu',NULL),(5,'First73','Last156','un111','pw37','un111@domain178.edu',NULL),(6,'First109','Last72','un50','pw188','un50@domain171.edu',NULL),(7,'First144','Last43','un23','pw59','un23@domain3.edu',NULL),(8,'First139','Last83','un107','pw132','un107@domain180.edu',NULL),(9,'First115','Last116','un20','pw71','un20@domain52.edu',NULL),(10,'First107','Last119','un62','pw110','un62@domain197.edu',NULL),(11,'First105','Last121','un117','pw112','un117@domain49.edu',NULL),(12,'First179','Last133','un25','pw146','un25@domain134.edu',NULL),(13,'First118','Last101','un104','pw10','un104@domain24.edu',NULL),(14,'First117','Last69','un79','pw69','un79@domain150.edu',NULL),(15,'First57','Last123','un112','pw102','un112@domain55.edu',NULL),(16,'First57','Last43','un101','pw19','un101@domain18.edu',NULL),(17,'First94','Last41','un188','pw21','un188@domain111.edu',NULL),(18,'First80','Last143','un55','pw41','un55@domain53.edu',NULL),(19,'First31','Last17','un31','pw18','un31@domain32.edu',NULL),(20,'First114','Last104','un180','pw100','un180@domain71.edu',NULL),(21,'First185','Last23','un41','pw5','un41@domain58.edu',NULL),(22,'First165','Last68','un83','pw50','un83@domain179.edu',NULL),(23,'First12','Last113','un171','pw22','un171@domain123.edu',NULL),(24,'First189','Last164','un187','pw37','un187@domain199.edu',NULL),(25,'First29','Last44','un152','pw129','un152@domain22.edu',NULL),(26,'First199','Last188','un114','pw106','un114@domain196.edu',NULL),(27,'First11','Last143','un111','pw188','un111@domain129.edu',NULL),(28,'First100','Last38','un8','pw159','un8@domain135.edu',NULL),(29,'First158','Last102','un39','pw147','un39@domain197.edu',NULL),(30,'First129','Last176','un138','pw130','un138@domain75.edu',NULL),(31,'First141','Last49','un151','pw104','un151@domain21.edu',NULL),(32,'First174','Last39','un100','pw12','un100@domain189.edu',NULL),(33,'First66','Last36','un67','pw101','un67@domain193.edu',NULL),(34,'First84','Last159','un79','pw136','un79@domain175.edu',NULL),(35,'First87','Last97','un44','pw165','un44@domain115.edu',NULL),(36,'First10','Last44','un47','pw40','un47@domain28.edu',NULL),(37,'First186','Last36','un7','pw189','un7@domain100.edu',NULL),(38,'First18','Last158','un112','pw97','un112@domain149.edu',NULL),(39,'First56','Last50','un140','pw150','un140@domain182.edu',NULL),(40,'First80','Last13','un50','pw56','un50@domain40.edu',NULL),(41,'First35','Last114','un129','pw9','un129@domain66.edu',NULL),(42,'First0','Last65','un33','pw195','un33@domain113.edu',NULL),(43,'First40','Last105','un152','pw17','un152@domain135.edu',NULL),(44,'First120','Last66','un151','pw116','un151@domain190.edu',NULL),(45,'First52','Last11','un167','pw18','un167@domain143.edu',NULL),(46,'First42','Last124','un167','pw76','un167@domain109.edu',NULL),(47,'First10','Last186','un100','pw176','un100@domain95.edu',NULL),(48,'First28','Last59','un115','pw99','un115@domain154.edu',NULL),(49,'First74','Last158','un5','pw40','un5@domain70.edu',NULL),(50,'First52','Last189','un59','pw80','un59@domain114.edu',NULL),(51,'First195','Last5','un62','pw66','un62@domain87.edu',NULL),(52,'First133','Last90','un37','pw128','un37@domain62.edu',NULL),(53,'First123','Last64','un123','pw47','un123@domain177.edu',NULL),(54,'First111','Last79','un12','pw65','un12@domain41.edu',NULL),(55,'First149','Last128','un73','pw56','un73@domain62.edu',NULL),(56,'First67','Last44','un157','pw127','un157@domain37.edu',NULL),(57,'First68','Last44','un103','pw189','un103@domain157.edu',NULL),(58,'First9','Last151','un199','pw98','un199@domain29.edu',NULL),(59,'First1','Last25','un3','pw93','un3@domain138.edu',NULL),(60,'First24','Last193','un61','pw12','un61@domain131.edu',NULL),(61,'First99','Last117','un52','pw156','un52@domain31.edu',NULL),(62,'First23','Last167','un34','pw67','un34@domain166.edu',NULL),(63,'First143','Last176','un152','pw74','un152@domain137.edu',NULL),(64,'First16','Last67','un84','pw152','un84@domain37.edu',NULL),(65,'First8','Last17','un128','pw81','un128@domain173.edu',NULL),(66,'First78','Last40','un24','pw57','un24@domain43.edu',NULL),(67,'First48','Last46','un109','pw100','un109@domain38.edu',NULL),(68,'First14','Last195','un178','pw7','un178@domain60.edu',NULL),(69,'First174','Last83','un153','pw149','un153@domain150.edu',NULL),(70,'First112','Last33','un105','pw79','un105@domain164.edu',NULL),(71,'First198','Last189','un96','pw139','un96@domain37.edu',NULL),(72,'First87','Last108','un121','pw175','un121@domain100.edu',NULL),(73,'First79','Last11','un78','pw76','un78@domain199.edu',NULL),(74,'First32','Last134','un4','pw12','un4@domain90.edu',NULL),(75,'First40','Last170','un126','pw136','un126@domain46.edu',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-21 21:13:01
