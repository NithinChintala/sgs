-- MySQL dump 10.13  Distrib 8.0.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sgs
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'fn10','ln151','un21','pw51','un21@domain137.edu',NULL),(2,'fn120','ln158','un148','pw16','un148@domain49.edu',NULL),(3,'fn84','ln87','un174','pw36','un174@domain115.edu',NULL),(4,'fn73','ln168','un91','pw190','un91@domain131.edu',NULL),(5,'fn73','ln156','un111','pw37','un111@domain178.edu',NULL),(6,'fn109','ln72','un50','pw188','un50@domain171.edu',NULL),(7,'fn144','ln43','un23','pw59','un23@domain3.edu',NULL),(8,'fn139','ln83','un107','pw132','un107@domain180.edu',NULL),(9,'fn115','ln116','un20','pw71','un20@domain52.edu',NULL),(10,'fn107','ln119','un62','pw110','un62@domain197.edu',NULL),(11,'fn105','ln121','un117','pw112','un117@domain49.edu',NULL),(12,'fn179','ln133','un25','pw146','un25@domain134.edu',NULL),(13,'fn118','ln101','un104','pw10','un104@domain24.edu',NULL),(14,'fn117','ln69','un79','pw69','un79@domain150.edu',NULL),(15,'fn57','ln123','un112','pw102','un112@domain55.edu',NULL),(16,'fn57','ln43','un101','pw19','un101@domain18.edu',NULL),(17,'fn94','ln41','un188','pw21','un188@domain111.edu',NULL),(18,'fn80','ln143','un55','pw41','un55@domain53.edu',NULL),(19,'fn31','ln17','un31','pw18','un31@domain32.edu',NULL),(20,'fn114','ln104','un180','pw100','un180@domain71.edu',NULL),(21,'fn185','ln23','un41','pw5','un41@domain58.edu',NULL),(22,'fn165','ln68','un83','pw50','un83@domain179.edu',NULL),(23,'fn12','ln113','un171','pw22','un171@domain123.edu',NULL),(24,'fn189','ln164','un187','pw37','un187@domain199.edu',NULL),(25,'fn29','ln44','un152','pw129','un152@domain22.edu',NULL),(26,'fn199','ln188','un114','pw106','un114@domain196.edu',NULL),(27,'fn11','ln143','un111','pw188','un111@domain129.edu',NULL),(28,'fn100','ln38','un8','pw159','un8@domain135.edu',NULL),(29,'fn158','ln102','un39','pw147','un39@domain197.edu',NULL),(30,'fn129','ln176','un138','pw130','un138@domain75.edu',NULL),(31,'fn141','ln49','un151','pw104','un151@domain21.edu',NULL),(32,'fn174','ln39','un100','pw12','un100@domain189.edu',NULL),(33,'fn66','ln36','un67','pw101','un67@domain193.edu',NULL),(34,'fn84','ln159','un79','pw136','un79@domain175.edu',NULL),(35,'fn87','ln97','un44','pw165','un44@domain115.edu',NULL),(36,'fn10','ln44','un47','pw40','un47@domain28.edu',NULL),(37,'fn186','ln36','un7','pw189','un7@domain100.edu',NULL),(38,'fn18','ln158','un112','pw97','un112@domain149.edu',NULL),(39,'fn56','ln50','un140','pw150','un140@domain182.edu',NULL),(40,'fn80','ln13','un50','pw56','un50@domain40.edu',NULL),(41,'fn35','ln114','un129','pw9','un129@domain66.edu',NULL),(42,'fn0','ln65','un33','pw195','un33@domain113.edu',NULL),(43,'fn40','ln105','un152','pw17','un152@domain135.edu',NULL),(44,'fn120','ln66','un151','pw116','un151@domain190.edu',NULL),(45,'fn52','ln11','un167','pw18','un167@domain143.edu',NULL),(46,'fn42','ln124','un167','pw76','un167@domain109.edu',NULL),(47,'fn10','ln186','un100','pw176','un100@domain95.edu',NULL),(48,'fn28','ln59','un115','pw99','un115@domain154.edu',NULL),(49,'fn74','ln158','un5','pw40','un5@domain70.edu',NULL),(50,'fn52','ln189','un59','pw80','un59@domain114.edu',NULL),(51,'fn195','ln5','un62','pw66','un62@domain87.edu',NULL),(52,'fn133','ln90','un37','pw128','un37@domain62.edu',NULL),(53,'fn123','ln64','un123','pw47','un123@domain177.edu',NULL),(54,'fn111','ln79','un12','pw65','un12@domain41.edu',NULL),(55,'fn149','ln128','un73','pw56','un73@domain62.edu',NULL),(56,'fn67','ln44','un157','pw127','un157@domain37.edu',NULL),(57,'fn68','ln44','un103','pw189','un103@domain157.edu',NULL),(58,'fn9','ln151','un199','pw98','un199@domain29.edu',NULL),(59,'fn1','ln25','un3','pw93','un3@domain138.edu',NULL),(60,'fn24','ln193','un61','pw12','un61@domain131.edu',NULL),(61,'fn99','ln117','un52','pw156','un52@domain31.edu',NULL),(62,'fn23','ln167','un34','pw67','un34@domain166.edu',NULL),(63,'fn143','ln176','un152','pw74','un152@domain137.edu',NULL),(64,'fn16','ln67','un84','pw152','un84@domain37.edu',NULL),(65,'fn8','ln17','un128','pw81','un128@domain173.edu',NULL),(66,'fn78','ln40','un24','pw57','un24@domain43.edu',NULL),(67,'fn48','ln46','un109','pw100','un109@domain38.edu',NULL),(68,'fn14','ln195','un178','pw7','un178@domain60.edu',NULL),(69,'fn174','ln83','un153','pw149','un153@domain150.edu',NULL),(70,'fn112','ln33','un105','pw79','un105@domain164.edu',NULL),(71,'fn198','ln189','un96','pw139','un96@domain37.edu',NULL),(72,'fn87','ln108','un121','pw175','un121@domain100.edu',NULL),(73,'fn79','ln11','un78','pw76','un78@domain199.edu',NULL),(74,'fn32','ln134','un4','pw12','un4@domain90.edu',NULL),(75,'fn40','ln170','un126','pw136','un126@domain46.edu',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-11 20:38:00
